package Entornos;

import static org.junit.Assert.*;
import org.junit.Test;

public class UtilsTest {

    // Comprueba un triángulo válido
    @Test
    public void testEsTrianguloTrue() {
        assertTrue(Utils.esTriangulo(3, 4, 5));
    }

    // Comprueba un caso que no es triángulo
    @Test
    public void testEsTrianguloFalse() {
        assertFalse(Utils.esTriangulo(1, 2, 10));
    }

    // Triángulo equilátero
    @Test
    public void testTipoTrianguloEquilatero() {
        assertEquals("EQUILATERO", Utils.tipoTriangulo(5, 5, 5));
    }

    // Triángulo isósceles
    @Test
    public void testTipoTrianguloIsosceles() {
        assertEquals("ISOSCELES", Utils.tipoTriangulo(5, 5, 3));
    }

    // Triángulo escaleno
    @Test
    public void testTipoTrianguloEscaleno() {
        assertEquals("ESCALENO", Utils.tipoTriangulo(3, 4, 5));
    }

    // Valores que no forman triángulo
    @Test
    public void testTipoTrianguloError() {
        assertEquals("ERROR", Utils.tipoTriangulo(1, 2, 10));
    }

    // Comprueba el número más frecuente
    @Test
    public void testMasFrecuenteInt() {
        int[] datos = {4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3};
        assertEquals(4, Utils.masFrecuenteInt(datos));
    }

    // Busca un número existente
    @Test
    public void testBuscarIntEncontrado() {
        int[] datos = {10, 20, 30, 40};
        assertEquals(2, Utils.buscarInt(datos, 30));
    }

    // Busca un número que no existe
    @Test
    public void testBuscarIntNoEncontrado() {
        int[] datos = {10, 20, 30, 40};
        assertEquals(-1, Utils.buscarInt(datos, 99));
    }
}
