package Entornos;

public class Utils {

	public static boolean esTriangulo(int a, int b, int c) {
		return a > 0 && b > 0 && c > 0 && a + b > c && a + c > b && b + c > a;
	}

	public static String tipoTriangulo(int a, int b, int c) {

		if (!esTriangulo(a, b, c)) {
			return "ERROR";
		}

		if (a == b && b == c) {
			return "EQUILATERO";
		}

		if (a == b || a == c || b == c) {
			return "ISOSCELES";
		}

		return "ESCALENO";
	}

	public static int masFrecuenteInt(int[] array) {

		int maxVeces = 0;
		int masFrecuente = array[0];

		for (int i = 0; i < array.length; i++) {
			int contador = 0;

			for (int j = 0; j < array.length; j++) {
				if (array[i] == array[j]) {
					contador++;
				}
			}

			if (contador > maxVeces) {
				maxVeces = contador;
				masFrecuente = array[i];
			}
		}

		return masFrecuente;
	}

	public static int buscarInt(int[] array, int valor) {

		for (int i = 0; i < array.length; i++) {
			if (array[i] == valor) {
				return i;
			}
		}

		return -1;
	}
}
